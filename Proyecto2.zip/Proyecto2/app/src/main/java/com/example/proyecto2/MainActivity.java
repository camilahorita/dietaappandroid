package com.example.proyecto2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
// inicializacion hecha con un constructor
        Persona objetoPaco = new Persona("Paco", "Berenguer", 45, 85.5, 1.78);

     /*   objetoPaco.setNombre("Paco");
        objetoPaco.appelidos = "Berenguer";
        objetoPaco.setEdad(45);
        objetoPaco.peso = 85.5f;
        objetoPaco.estatura = 1.75;

      */
//        System.out.prinln()  --> imprimir en pantalla lo que entre haya en sus paréntesis

        System.out.println(objetoPaco.valores());
//        TOAST
        Toast.makeText(this, objetoPaco.valores(), Toast.LENGTH_LONG).show();

    }

}