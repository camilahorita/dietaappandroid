package com.example.proyecto2;

// modificadores de acceso: private solo accesible desde la clase actual
// - sin nada: accesible desde cualquier clase
// - protected accesible desde la clase actual y sys descendientes
//  -public accesible desde cualquier clase

// GET con ele accedemos y recuperamos valores ya asignados de atributos/ nos devuelve valores de atributos
// SET Asignamos valores iniciales a atributos o modificamos los valores
//SOLO necesito inicializar los objetos cuando pongo private , para inicializar hacer click con el boton derecho del raton
//y hacer click en generate

public class Persona {
    private String nombre;
    String appelidos;
    private int edad;
    double peso;
    double estatura;

//    CONSTRUCTORES -SINTAXIS - serve para inicializar una clase de modo distinto
//    MODIFICADOR NOMBREDELCONSTRUCTOR(listadeParametros) throws listaExcepeciones {
// }
    public Persona(String nombre, String appelidos, int edad, double peso, double estatura){
        this.nombre = nombre;
        this.appelidos = appelidos;
        this.edad =edad;
        this.peso =peso;
        this.estatura = estatura;

    }

//    criar un nuevo metodo
    private double IMC(){
        return  (peso/(estatura*estatura));
    }

    public String getNombre() {
        return nombre;
    }

    public String getAppelidos() {
        return appelidos;
    }

    public int getEdad() {
        return edad;
    }

    public double getPeso() {
        return peso;
    }

    public double getEstatura() {
        return estatura;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAppelidos(String appelidos) {
        this.appelidos = appelidos;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }

//    METODO SINTAXIS
//    void es un metodo que no retornará nada, otros metodos booleran, string etc y return
    public String valores() {
        return "Nombre: " + nombre +"\n" +"Apellidos: " + appelidos +"\n"+ "Edad; " + edad + "\n"
                +"Peso: " + peso +"\n" + "Estatura: " + estatura + "\n" + "IMG: " + IMC();

    }
}
